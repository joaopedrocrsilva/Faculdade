int main()
{

    printf("Exercicio 2 \n");

    int massa_inicial;

    printf("Informe a massa inicial do material: ");
    scanf("%d", &massa_inicial);

    double meia_vida = massa_inicial/2;
    double massa_perda = 0.5;

    

    while (massa_inicial > massa_perda){
        meia_vida;
        if (massa_inicial < massa_perda){
            printf("Massa inicial: ", massa_inicial);
            printf("Tempo");
        }else{
            prinf("Erro");
        }
    }

        
         
} 
